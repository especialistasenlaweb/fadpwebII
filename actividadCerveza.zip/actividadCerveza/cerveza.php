<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Cerveza</title>
</head>
<body>

	<form action="" method="post">
		Nombre: <input type="text" name="n">
		<br>
		Cantidad: <input type="number" min="0" name="c">
		<br>
		Quieres Robar:<input type="checkbox" name="robar">
		<br>
		<input type="submit">
	</form>

	<?php 
		if ($_POST) {
			$n=$_POST['n'];
			$c=$_POST['c'];
			$precio=1500;
			$subtotal=$c*$precio;
			$iva=($subtotal*19)/100;

			if(isset($_POST['robar'])){
				$incremento=0;
			}else{
				$incremento=($subtotal*8)/100;
			}
			$total=$subtotal+$incremento+$iva;

			if ($c>10) {
				echo "<hr>Borrachin....<hr>";
				echo "<img src='fotoborracho.jpg'>";
			}else{
				echo "<hr>tacañin<hr>";
				echo "<img src='fototaca.jpg'>";
			}

			echo "Hola $n <br> Cantidad $c <br> Impuesto:$incremento<br>Iva: $iva <br> Subtotal: $subtotal <br> Total: $total";
		}

	 ?>
</body>
</html>